# Agile Methodology & Sprint Plan — Enterprise Code Intelligence Platform (ECIP)

ECIP development is structured using the Agile Scrum framework. This ensures modular deliverables, continuous integration checks, and iterative quality testing at the end of each two-week sprint.

---

## 1. Scrum Ceremony Structures

### 1.1 Iteration Cadence
- **Sprint Duration:** 2 weeks (10 working days).
- **Daily Standup:** 15 minutes daily. Focus: *What was done yesterday, what will be done today, and are there any blocker impediments?*
- **Backlog Refinement:** Once per sprint (mid-sprint). Groom stories, define explicit acceptance criteria, and re-estimate tickets.
- **Sprint Planning:** First day of the sprint. Commit to Sprint Goals and assign story points to the Sprint Backlog.
- **Sprint Review & Demo:** Last day of the sprint. Walk through a live demonstration of the functional features (running fully locally on 16GB laptops).
- **Sprint Retrospective:** Last day of the sprint (following Review). Evaluate what went well, what failed, and draft action items for improvement.

---

## 2. Story Pointing Sizing Guidelines
Story points are estimated using the Fibonacci sequence (1, 2, 3, 5, 8) mapping complexity, unknowns, and integration risks:

- **1 Point:** Trivial, clear task with zero external dependencies (e.g., *adding standard error log formats, editing local environment configs*).
- **2 Points:** Straightforward task with minimal complexity (e.g., *scaffolding basic FastAPI routers, writing simple file search logic*).
- **3 Points:** Moderate complexity involving database schema logic or basic API integrations (e.g., *building FAISS index writer classes, setting up Neo4j transaction handles*).
- **5 Points:** Highly complex task requiring AST traversals, custom graph patterns, or heavy algorithm optimizations (e.g., *writing the Java AST method parser, implementing hybrid keyword+vector search fusion*).
- **8 Points:** Extreme complexity with multi-component dependencies, high execution uncertainty, and testing risks (e.g., *writing the recursive BFS/DFS graph impact analysis engine, building the complete VS Code webview panel with line citation jumps*).

---

## 3. Definition of Done (DoD)
A story is marked as **Done** if and only if it meets the following criteria:

### 3.1 Code Quality
- Source code contains zero compiler warnings and passes linting checks (e.g., `pylint`, `mypy` strict type checking for Python).
- Clean code architecture: class interfaces respect Port and Adapter boundary abstractions.
- No secrets (e.g., database passwords, local auth tokens) are checked into git tracking.

### 3.2 Verification and Test Coverage
- Unit tests exist covering all core method paths.
- Code coverage is evaluated and meets a **minimum of 80% line coverage**.
- All integration tests pass against the local workspace environment cache.

### 3.3 Security compliance
- Zero network connection checks passed: No external calls reside in the codebase.
- Audit tracing logs are triggered and written correctly.

### 3.4 Documentation
- Markdown documentation inside `Documenatations/` updated to match any structural changes.
- Javadoc / docstrings exist for all new public interfaces and schemas.

---

## 4. Sprint Roadmap (Phases 1 & 2 Breakdown)

### Sprint 1: Environment & Base Model
- **Goal:** Get the core daemon responding to requests and running model inference.
- **Backlog Items:**
  - Setup Python FastAPI directory framework. (2 points)
  - Configure Ollama local orchestrator and verify Qwen2.5-Coder model response speed. (3 points)
  - Build prompt validation schemas and logs database using SQLite. (3 points)

### Sprint 2: Code Ingestion & Vector Base
- **Goal:** Walk workspaces, generate chunks, and build local vector indices.
- **Backlog Items:**
  - Create recursive workspace file walker ignoring `.gitignore` files. (2 points)
  - Create syntactic method chunking engine. (5 points)
  - Connect `SentenceTransformer` to FAISS database index. (3 points)

### Sprint 3: Hybrid Search Retrieval
- **Goal:** Implement semantic plus keyword retrieval searches.
- **Backlog Items:**
  - Build local SQLite catalog mapper. (3 points)
  - Integrate BM25 search indices. (5 points)
  - Develop Reciprocal Rank Fusion (RRF) combiner and prompt builder. (5 points)

### Sprint 4: AST Code Parsing
- **Goal:** Parse Java classes, dependencies, and mappings.
- **Backlog Items:**
  - Develop the Java AST parser connector. (5 points)
  - Extract Rest controller endpoints and mapper relations. (5 points)
  - Parse SQL database migration scripts. (3 points)

### Sprint 5: Dependency Graph Construction
- **Goal:** Populate Neo4j graph schemas from parsed code metrics.
- **Backlog Items:**
  - Define Neo4j node and edge constraints. (3 points)
  - Develop graph exporter logic to populate database structures. (5 points)
  - Implement basic Cypher queries testing call chain outputs. (3 points)
