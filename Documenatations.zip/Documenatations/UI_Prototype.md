# User Interface Prototype — Enterprise Code Intelligence Platform (ECIP)

This document contains text-based visual mockups representing the layout, interface designs, and interactive elements of ECIP inside developer tools.

---

## 1. VS Code Sidebar Chat Interface Layout
The sidebar panel renders as a dedicated Webview inside VS Code. It displays conversation states, indexing status flags, and grounded code citations.

```text
+-----------------------------------------------------------------+
| [ECIP] CODE INTELLIGENCE PLATFORM                    [X] [?] [-] |
+-----------------------------------------------------------------+
| STATUS: (o) Indexing Complete  [24,198 classes mapped]          |
| REPO:   /Users/samirzade/Codes/LLM-Env/ (Branch: main)          |
+-----------------------------------------------------------------+
|                                                                 |
|  [USER]: Explain how candidate status is updated in our app.    |
|                                                                 |
|  [ECIP]: Candidate status changes occur within CandidateService  |
|  which is mapped to CandidateEntity. Following HR approval:     |
|                                                                 |
|  1. CandidateController maps HTTP POST to endpoint path         |
|     `/candidates/{id}/approve`                                  |
|  2. Calls CandidateService.approve() method                     |
|  3. Status field updates to APPROVED and changes are written    |
|     to DB via CandidateRepository.save()                        |
|                                                                 |
|  +-- [Grounded References & Citations] ----------------------+  |
|  | [1] CandidateController.java (lines 40-52)               |  |
|  | [2] CandidateService.java (lines 112-140)                |  |
|  | [3] CandidateRepository.java (lines 18-24)                |  |
|  +-----------------------------------------------------------+  |
|                                                                 |
+-----------------------------------------------------------------+
|  [ Ask a question about your workspace...                     ] |
|                                                                 |
|  [ ] Include Graph Context  [ ] Format as Diff   [ Send (Enter) ]|
+-----------------------------------------------------------------+
| Actions: [Generate JUnit]  [Explain Error]  [Run Impact Check]  |
+-----------------------------------------------------------------+
```

---

## 2. IDE Editor Inline Context Menu
Right-clicking any selected class, method, or block of code triggers context-specific operations:

```text
+----------------------------------------+
| Copy                                   |
| Paste                                  |
| Find Usages                            |
| Refactor                         >     |
+----------------------------------------+
| ECIP AI Actions                  >     | +-----------------------------------+
+----------------------------------------+ | [1] Explain selected code           |
| Format Document                        | | [2] Generate JUnit tests            |
| Git Add / Commit                       | | [3] Analyze upstream impact         |
+----------------------------------------+ | [4] Check project style compliance  |
                                           +-----------------------------------+
```

---

## 3. Web Management Console Configuration Page
A browser UI interface running locally (`http://localhost:8000/admin`) designed to configure the daemon parameters.

```text
===================================================================================
  ECIP ADMIN CONSOLE  |  Dashboard  |  Index Settings  |  Model Config  |  Logs
===================================================================================

[ INDEX SETTINGS ]
-----------------------------------------------------------------------------------
Active Workspace Path:  [/Users/samirzade/Codes/LLM-Env/          ]  [ Browse... ]
Exclude Folders:        [target/, .git/, node_modules/, dist/     ]
Supported Formats:      [x] .java   [x] .sql   [x] .yml   [x] .xml   [ ] .properties

Vector Index Status:    READY (5,104 nodes vectorized)              [ Re-Index ]
Graph Index Status:     CONNECTED (Neo4j local instance: port 7687)  [ Test Conn ]

[ MODEL INFRASTRUCTURE CONFIG ]
-----------------------------------------------------------------------------------
Execution Profile:      (•) Laptop Mode (Local CPU/iGPU via Ollama)
                        ( ) Server Mode (Remote vLLM API server)

Ollama Socket Address:  [http://localhost:11434                            ]
Selected Model:         [qwen2.5-coder:7b-instruct-q4_K_M                  ] [v]
Embedding Model:        [BAAI/bge-code-v1                                  ] [v]

Project Memory File:    [~/.gemini/config/AGENTS.md                        ] [v]

[ Save Settings ]                                      [ System Diagnostics Pass ]
===================================================================================
```

---

## 4. Impact Analysis Path Representation
When executing `/api/v1/impact` on a column change, the IDE displays a tree view of dependent components:

```text
===================================================================================
[ECIP IMPACT ANALYSIS ENGINE] Target: DB Column [CANDIDATES.STATUS]
===================================================================================
( ! ) High Impact Warning: Altering this column affects 3 layers.

[+] DB Column: CANDIDATES.STATUS
 │
 ├──[MAPPED]──> JPA Entity Field: CandidateEntity.candidateStatus
 │               │
 │               ├──[REFERENCED]──> Repository method: CandidateRepository.findByStatus()
 │               │                   │
 │               │                   └──[CALLER]──> Service class: CandidateService.java:L82
 │               │
 │               └──[MAPPED_TO]──> Transfer Object: CandidateDTO.java:L14
 │                                   │
 │                                   └──[RETURNED]──> REST Controller: CandidateController.java:L45
 │                                                      │
 │                                                      └──[CONSUMER]──> React View: CandidatePage.tsx:L89
 │
 └──[TESTED_BY]──> Unit Test class: CandidateServiceTest.java:L204
===================================================================================
```
