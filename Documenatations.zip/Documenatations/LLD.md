# Low-Level Design (LLD) — Enterprise Code Intelligence Platform (ECIP)

## 1. Directory Structure of Implementation
```text
ecip-core/
│
├── config/
│   ├── __init__.py
│   └── settings.py         # Config resolver (Env vars, paths, database credentials)
│
├── ingestion/
│   ├── __init__.py
│   ├── file_walker.py      # Recursive file scanning & hash delta verification
│   ├── chunker.py          # Abstract AST method boundaries chunker
│   └── pipeline.py         # Ingestion orchestration orchestrating Parsers and Embeddings
│
├── parsers/
│   ├── __init__.py
│   ├── java_parser.py      # Java parsing class (methods, annotations, dependencies)
│   ├── sql_parser.py       # SQL DDL parsing class
│   └── config_parser.py    # YAML, XML, properties configurations parser
│
├── indexers/
│   ├── __init__.py
│   ├── faiss_indexer.py    # FAISS local vector indices adapter
│   ├── neo4j_indexer.py    # Neo4j Cypher statements transaction manager
│   └── sqlite_indexer.py   # SQLite relational database catalog manager
│
├── retrieval/
│   ├── __init__.py
│   ├── search_service.py   # Hybrid vector + keyword search coordinator
│   ├── reranker.py         # Cross-encoder interface wrapper
│   └── graph_retriever.py  # Neo4j traversal collector for class/endpoint context
│
├── inference/
│   ├── __init__.py
│   └── ollama_client.py    # HTTP client for Ollama API endpoint communication
│
├── api/
│   ├── __init__.py
│   ├── routes/
│   │   ├── chat.py         # API endpoints for conversation workflows
│   │   └── impact.py       # API endpoints for impact analysis execution
│   └── models.py           # Pydantic schemas validating API inputs/outputs
│
├── main.py                 # FastAPI application initializer
└── requirements.txt
```

---

## 2. Component Code Interface Design

### 2.1 File Walker & Change Monitor (`ingestion/file_walker.py`)
```python
import os
import hashlib
from typing import Set, Dict

class FileWalker:
    def __init__(self, workspace_path: str, supported_extensions: Set[str]):
        self.workspace_path = workspace_path
        self.supported_extensions = supported_extensions

    def calculate_file_hash(self, file_path: str) -> str:
        """Calculates MD5 hash of file to check for changes."""
        hasher = hashlib.md5()
        with open(file_path, 'rb') as f:
            buf = f.read(65536)
            while len(buf) > 0:
                hasher.update(buf)
                buf = f.read(65536)
        return hasher.hexdigest()

    def scan(self, existing_hashes: Dict[str, str]) -> Dict[str, str]:
        """Scans folder recursively, returning list of path: hash values."""
        current_hashes = {}
        for root, _, files in os.walk(self.workspace_path):
            # Skip directories like .git or node_modules
            if any(part in root.split(os.sep) for part in [".git", "node_modules", "target"]):
                continue
            for file in files:
                ext = os.path.splitext(file)[1]
                if ext in self.supported_extensions:
                    full_path = os.path.join(root, file)
                    current_hashes[full_path] = self.calculate_file_hash(full_path)
        return current_hashes
```

### 2.2 AST Java Parser (`parsers/java_parser.py`)
```python
from typing import Dict, List, Any

class JavaASTParser:
    def __init__(self):
        pass

    def parse_file(self, content: str) -> Dict[str, Any]:
        """
        Parses Java code using AST tree walkers.
        Returns:
            {
               "classes": [{"name": "UserService", "annotations": ["@Service"]}],
               "methods": [{"name": "saveUser", "signature": "public void saveUser(UserDTO dto)", "calls": [...]}]
            }
        """
        # Lexical validation and AST walking implementation
        pass

    def extract_dependencies(self, class_ast: Any) -> List[str]:
        """Finds dependencies injected in constructor parameters."""
        pass
```

### 2.3 Hybrid Search Coordinator (`retrieval/search_service.py`)
```python
from typing import List, Dict, Any

class HybridSearchCoordinator:
    def __init__(self, faiss_client: Any, sqlite_client: Any, bm25_index: Any):
        self.faiss = faiss_client
        self.sqlite = sqlite_client
        self.bm25 = bm25_index

    def compute_query_embedding(self, query: str) -> List[float]:
        """Calls local embedding model to vectorize the query."""
        pass

    def search(self, query: str, top_k: int = 10) -> List[Dict[str, Any]]:
        """
        Executes parallel searches:
        1. FAISS vector distance calculation
        2. SQLite full-text search (FTS) / BM25
        3. Ranks results using Reciprocal Rank Fusion (RRF)
        """
        vector_results = self.faiss.search(self.compute_query_embedding(query), top_k)
        keyword_results = self.bm25.search(query, top_k)
        
        # Merge, deduplicate, and sort combined results
        return self.merge_and_rank(vector_results, keyword_results)

    def merge_and_rank(self, l1: List[Dict], l2: List[Dict]) -> List[Dict]:
        pass
```

### 2.4 Graph Traversal Engine (`retrieval/graph_retriever.py`)
```python
from neo4j import GraphDatabase
from typing import List, Dict, Any

class GraphDependencyRetriever:
    def __init__(self, uri: str, auth: tuple):
        self.driver = GraphDatabase.driver(uri, auth=auth)

    def close(self):
        self.driver.close()

    def get_downstream_impact(self, node_name: str, node_type: str) -> List[Dict[str, Any]]:
        """
        Queries Neo4j utilizing Cypher traversal.
        Traces path: (Node) -[*1..5]-> (Dependent Node)
        """
        query = (
            f"MATCH (start:{node_type} {{name: $name}})"
            "MATCH path = (start)-[*1..5]->(impacted)"
            "RETURN impacted.name as name, labels(impacted)[0] as type, "
            "[n in nodes(path) | labels(n)[0] + ':' + n.name] as trace_path"
        )
        with self.driver.session() as session:
            result = session.run(query, name=node_name)
            return [record.data() for record in result]
```

---

## 3. Pydantic API Validation Schemas (`api/models.py`)

Here are the strict API constraints defined using Pydantic:

```python
from pydantic import BaseModel, Field
from typing import List, Optional, Tuple

class FileContext(BaseModel):
    path: str = Field(..., description="File path relative to repository root")
    line_range: Optional[Tuple[int, int]] = Field(None, description="Start and end line numbers")

class ChatMessage(BaseModel):
    role: str = Field(..., pattern="^(user|assistant|system)$")
    content: str = Field(..., min_length=1)

class ChatRequest(BaseModel):
    query: str = Field(..., min_length=2)
    file_context: Optional[FileContext] = None
    history: List[ChatMessage] = Field(default_factory=list)

class Citation(BaseModel):
    file_path: str
    lines: str

class ChatResponseChunk(BaseModel):
    token: str
    is_done: bool
    citations: Optional[List[Citation]] = None

class ImpactRequest(BaseModel):
    target_node: str = Field(..., min_length=1)
    target_type: str = Field(..., pattern="^(Class|Method|Endpoint|DatabaseTable|DatabaseColumn)$")

class ImpactedComponent(BaseModel):
    component: str
    type: str
    relationship_path: str

class ImpactResponse(BaseModel):
    target_node: str
    impacted_components: List[ImpactedComponent]
```
These schema models guarantee that any inbound validation fails immediately (HTTP 422 Unprocessable Entity) if fields are missing or pattern requirements are violated, protecting the backend parser workflows.
