# High-Level Design (HLD) — Enterprise Code Intelligence Platform (ECIP)

## 1. System Topology Architecture

ECIP acts as a local daemon or isolated server cluster that bridges developer workflows in IDEs with secure local vector search, graph structures, and AI models.

```mermaid
graph TD
    subgraph IDE_Layer["IDE & Editor Extensions"]
        VSCode["VS Code Extension"]
        IntelliJ["IntelliJ IDEA Plugin"]
    end

    subgraph Core_Daemon["ECIP Local Service (FastAPI)"]
        Gateway["Enterprise API Gateway"]
        Parser["Parser Engine (Java, SQL, Git, YAML)"]
        RAG_Engine["RAG Retrieval Engine"]
        Graph_Engine["Graph Traversal Engine"]
        Sys_Memory["Project Memory Store"]
    end

    subgraph Data_Storage["Data Storage Layer"]
        FAISS["FAISS Index (Vector DB)"]
        SQLite["SQLite (Metadata & Audits)"]
        Neo4j["Neo4j Database (Graph DB)"]
    end

    subgraph Local_Inference["Inference Layer (Air-Gapped)"]
        Ollama["Ollama Daemon"]
        CodingModel["Qwen2.5-Coder / DeepSeek-Coder"]
    end

    %% Communications
    VSCode <-->|REST / SSE JSON| Gateway
    IntelliJ <-->|REST / SSE JSON| Gateway
    
    Gateway --> Parser
    Gateway --> RAG_Engine
    Gateway --> Graph_Engine
    
    Parser -->|Write relationships| Neo4j
    Parser -->|Write code chunks| SQLite
    Parser -->|Embed & Write vectors| FAISS
    
    RAG_Engine -->|Query vectors| FAISS
    Graph_Engine -->|Cypher queries| Neo4j
    
    RAG_Engine -->|Retrieve context| SQLite
    Sys_Memory -->|Prepend context| RAG_Engine
    
    RAG_Engine -->|Consolidated Prompt| Ollama
    Ollama <-->|Stream inference| CodingModel
    Ollama -->|Stream Tokens| Gateway
```

---

## 2. Logical Components Breakdown

### 2.1 Developer IDE Integration Layer
- **Interface:** Front-facing panels (webviews) built using HTML5/TypeScript (VS Code) and Swing/Kotlin (IntelliJ).
- **Communication:** Communication with the Core Daemon occurs via local loopback sockets using HTTP REST for commands (e.g., triggering a repository scan) and Server-Sent Events (SSE) for chat streaming.
- **Line Citations Jump:** When the backend provides references, the IDE extension translates file paths and line offsets into editor focus commands to position the developer’s active cursor at the exact code segment.

### 2.2 Core Daemon Engine (FastAPI)
The central intelligence coordinator containing:
- **API Gateway:** Validates security tokens, manages rate limits, and routes queries.
- **Parsing Router:** Watches files for changes, schedules asynchronous parse tasks, and routes files to specific parsing modules.
- **RAG Coordinator:** Aggregates inputs, triggers semantic database lookups, calls the graph-traversal engine, structures the final prompt template, and manages response caching.
- **Project Memory Manager:** Maintains persistent state files describing the environment rules.

### 2.3 Storage and Database Layer
- **FAISS (Facebook AI Similarity Search):** Store vectors of embedding outputs. Highly optimized for CPU-based top-k nearest neighbor lookups.
- **SQLite Database:** Acts as the local catalog containing chunk text mapping tables, transaction logs, configuration values, and local audit metrics.
- **Neo4j Graph Database:** Executes Cypher queries to resolve structural linkages.

### 2.4 Inference Orchestration Layer
- **Inference Engine:** In laptop mode, it invokes local `Ollama` sockets (`localhost:11434`). In server mode, it calls the `vLLM` OpenAPI endpoints.
- **Model Loader:** Keeps model weights loaded in system RAM/VRAM, auto-offloading to disk or terminating the task during inactivity thresholds.

---

## 3. Core Architectural Design Patterns

### 3.1 Ports and Adapters (Hexagonal Architecture)
To ensure components are easily swappable (e.g., swapping FAISS for Qdrant, or Ollama for vLLM), the codebase is organized with clear boundary ports.

```mermaid
classDiagram
    class IngestionPort {
        <<interface>>
        +scan_repository(path: String)
        +chunk_file(file: String)
    }
    class RetrievalPort {
        <<interface>>
        +query_similarity(vector: List)
        +combine_results(vector_results: List, graph_results: List)
    }
    class InferencePort {
        <<interface>>
        +generate_response(prompt: String)
        +stream_tokens(prompt: String)
    }
    class JavaParserAdapter {
        +parse_ast()
    }
    class FAISSAdapter {
        +add_vectors()
        +search_vectors()
    }
    class OllamaAdapter {
        +call_completion()
    }

    IngestionPort <|.. JavaParserAdapter
    RetrievalPort <|.. FAISSAdapter
    InferencePort <|.. OllamaAdapter
```

### 3.2 Observer Pattern for Code Modification Walks
File change observers (`watchdog` library in Python) listen for file modifications inside the open workspace directory. When a file is written, notifications trigger an incremental parse-and-reindex pipeline, updating Vector and Graph databases asynchronously.

---

## 4. Neo4j Node and Relationship Topology
The structure below outlines the dependency linkages maintained inside the local Graph database. It is optimized for structural dependency checks and code impact path tracking.

```mermaid
graph LR
    %% Nodes
    C1["Class: CandidateController"]
    M1["Method: approveCandidate()"]
    E1["Endpoint: POST /candidates/{id}/approve"]
    S1["Class: CandidateService"]
    M2["Method: approve()"]
    R1["Class: CandidateRepository"]
    T1["DatabaseTable: CANDIDATES"]
    Col1["DatabaseColumn: STATUS"]

    %% Relationships
    E1 -->|ROUTES_TO| M1
    C1 -->|HAS_METHOD| M1
    M1 -->|CALLS| M2
    S1 -->|HAS_METHOD| M2
    M2 -->|DEPENDS_ON| R1
    R1 -->|QUERIES| T1
    T1 -->|HAS_COLUMN| Col1
```
This relational layout allows the graph engine to query: *"Find all Endpoint nodes that eventually lead to Class CandidateService"* using a simple Cypher query traversal.
