# ECIP — Full Build Plan
### Step-by-Step Execution Guide (Complete Project, Not Compressed)

> **Scope:** This document assumes you build the *entire* ECIP vision from the Master Documentation — all 6 pillars, full Knowledge Graph, real impact analysis, IDE plugins. Realistic total: **~12–15 months at solid part-time effort, or ~6–8 months if you can go full-time / part-team.** This is the "how" you asked for — broken into phases, weeks, and concrete daily tasks.

---

## 0. Before You Start — Decisions to Lock In

These four choices determine everything downstream. Decide them now so you don't rebuild later.

| Decision | Recommendation | Why |
|---|---|---|
| Base coding LLM | **Qwen2.5-Coder-7B-Instruct** (or DeepSeek-Coder-V2-Lite) | Best Java/Spring understanding in the 7–8B class, runs 4-bit on a 16GB laptop |
| Local runtime | **Ollama** for inference, **Unsloth/PEFT+LoRA** for fine-tuning | Ollama = zero-friction local serving; Unsloth = fast, memory-light LoRA |
| Graph store | **Neo4j Community (embedded/local)** | Native graph queries (Cypher) >> simulating graphs in SQLite for impact analysis |
| Vector store | **FAISS** locally → **Qdrant** when you need a server mode | FAISS has zero infra; Qdrant adds filtering + persistence cleanly later |

**Pick ONE real internal repo as your reference project** for the entire build (not a toy example). Every parser, every graph schema decision, every prompt template should be validated against this repo, end to end, throughout. This is the single biggest predictor of whether the final system is actually useful versus a demo toy.

---

## PHASE 1 — Foundation: Local LLM + Basic RAG (Weeks 1–8)

**Goal:** A developer can open the reference repo, index it, and ask questions through a terminal or simple script — fully offline.

### Week 1 — Environment & Base Model
- Day 1–2: Install Ollama, pull Qwen2.5-Coder-7B (4-bit). Verify it runs on your hardware and benchmark response latency.
- Day 3: Set up Python project structure (`ecip-core`): virtualenv, FastAPI skeleton, config management (`.env` for paths/models).
- Day 4: Write a basic prompt-test harness — feed the raw model 10 real questions about your reference repo *without* any retrieval, record answers. This is your "before" baseline to measure RAG improvement against later.
- Day 5: Set up logging/tracing for every LLM call (prompt in, response out, latency) — you'll need this for debugging retrieval quality for the rest of the project.

### Week 2 — Document & Code Ingestion (Naive)
- Day 1–2: Write a file walker that recursively scans the reference repo, filters by extension (`.java`, `.md`, `.yml`, `.xml`, `.sql`), respects `.gitignore`.
- Day 3–4: Build a chunker — split files into overlapping chunks (~300–500 tokens) with metadata (file path, line range). For Java files, chunk by method/class boundary where possible (don't just split blindly every N lines).
- Day 5: Store chunk metadata in a simple JSON/SQLite table: `chunk_id, file_path, start_line, end_line, content, content_hash`.

### Week 3 — Embeddings & Vector Store
- Day 1: Pick embedding model (e.g., `BAAI/bge-code-v1` or `nomic-embed-text` via SentenceTransformers) — code-aware embeddings outperform generic ones noticeably.
- Day 2–3: Build the embedding pipeline: chunk → embed → store vector in FAISS, mapped back to `chunk_id`.
- Day 4: Build incremental indexing — detect changed files (via content hash) and re-embed only those, not the whole repo every time.
- Day 5: Test: embed the full reference repo, time it, sanity-check index size on disk.

### Week 4 — Retrieval Pipeline v1
- Day 1–2: Build query → embed → FAISS top-k search → return chunks with metadata.
- Day 3: Add basic keyword/BM25 search (e.g., `rank_bm25`) and combine with vector search (simple hybrid: union + dedupe, no reranking yet).
- Day 4: Build prompt assembly: system context + retrieved chunks + question → structured prompt template (see Master Doc section 4.2 for the exact structure to follow).
- Day 5: Run your 10 baseline questions through the full RAG pipeline. Compare against Week 1 baseline — document the improvement (or lack of it) honestly.

### Week 5 — Quality Pass on Retrieval
- Day 1–2: Add a reranker (cross-encoder, e.g. `bge-reranker-base`) to reorder top-20 retrieved chunks down to top-5 most relevant.
- Day 3: Tune chunk size and overlap based on real failure cases from Week 4 testing.
- Day 4–5: Add response caching (hash of query + repo state → cached answer) for repeated questions.

### Week 6 — VS Code Extension (Minimal)
- Day 1–2: Scaffold a VS Code extension (TypeScript, `yo code` generator) with a sidebar webview panel.
- Day 3–4: Wire the webview chat UI to call your local FastAPI backend (`/ask` endpoint).
- Day 5: Add "insert code" / "copy answer" buttons, and clickable file:line citations that jump to the actual code.

### Week 7 — Fine-Tuning Pass 1
- Day 1–2: Collect 100–300 example Q&A pairs reflecting your company's coding standards (constructor injection, MapStruct usage, exception handling patterns) — write these manually based on real code review feedback if you don't have historical data.
- Day 3–4: LoRA fine-tune Qwen2.5-Coder on this dataset using Unsloth (a few hours on a rented GPU, e.g. RTX 4090 or A100 spot instance).
- Day 5: A/B test fine-tuned vs base model on standards-adherence questions ("write a service class following our conventions").

### Week 8 — Phase 1 Hardening
- Day 1–2: Error handling across the pipeline (empty index, model timeout, malformed files).
- Day 3: Write a basic eval set (20–30 Q&A pairs with expected answer characteristics) you can re-run after every future change to catch regressions.
- Day 4–5: Internal demo to yourself/a trusted peer. Fix the top 3 friction points found.

**✅ Phase 1 Definition of Done:** Open the reference repo in VS Code, ask real questions in the sidebar chat, get grounded answers with file citations — fully offline, no fine-tuning regressions vs Week 7 baseline.

---

## PHASE 2 — Parsers & Dependency Graph (Weeks 9–20, ~3 months)

**Goal:** Move from "text chunks" to real structural understanding.

### Weeks 9–11 — Java Parser
- Week 9: Integrate **JavaParser** (Java library — you'll run it as a small Java microservice or via a Python-Java bridge like `javalang` for a lighter pure-Python start). Extract: class name, type, annotations, fields, constructor parameters.
- Week 10: Extract methods (signature, return type, parameters), REST mappings (`@GetMapping`, `@PostMapping` + path), and constructor-injected dependencies.
- Week 11: Extract JPA entity annotations (`@Entity`, `@Column`, `@OneToMany` etc.) and Lombok-expanded fields. Test against 20+ real classes from the reference repo; manually verify accuracy.

### Weeks 12–13 — SQL & Config Parsers
- Week 12: SQL parser (use `sqlglot` or `ANTLR` SQL grammar) — extract tables, columns, PKs/FKs, indexes from migration scripts.
- Week 13: Config parsers: `pom.xml`/`build.gradle` (dependency list), `application.yml` (service config), `docker-compose.yml` (service topology).

### Weeks 14–15 — Documentation & Git Parsers
- Week 14: Documentation parser — markdown/README chunking (you mostly have this from Phase 1; extend to Confluence exports if available).
- Week 15: Git parser (`GitPython`) — commit history, authors, file change frequency, linking commits to files/classes touched.

### Weeks 16–17 — Build the Dependency Graph
- Week 16: Set up Neo4j (embedded mode). Design schema: node types (Class, Method, Endpoint, Table, Column) and edge types (CALLS, DEPENDS_ON, QUERIES, HAS_COLUMN, MAPPED_TO) — use the exact schema from Master Doc section 4.4 as your starting point.
- Week 17: Write the graph-builder: take parser output → create nodes/edges in Neo4j. Validate with Cypher queries: "show me everything CandidateService depends on" and manually verify against the real repo.

### Weeks 18–19 — Graph-Aware Retrieval
- Week 18: Extend the retrieval pipeline: when a vector search returns a class/method, also pull its 1-hop graph neighbors (callers, callees, related tables) and include them in the prompt.
- Week 19: Test on real questions: "what calls this service," "what tables does this entity touch." Compare answer quality against Phase 1 (pure RAG) on the same questions.

### Week 20 — Phase 2 Hardening & Swagger/React Parsers (start)
- Day 1–2: Swagger/OpenAPI parser (straightforward — it's structured JSON/YAML already).
- Day 3–5: Basic React component parser (regex/AST via `@babel/parser` if frontend exists in your reference repo) — extract component names, API calls made (`fetch`/`axios` calls), props.

**✅ Phase 2 Definition of Done:** Ask "what calls this service?" or "what depends on this entity?" and get an answer sourced from the actual dependency graph, verifiable by you against the real codebase, not just plausible-sounding text.

---

## PHASE 3 — Knowledge Graph & Impact Analysis (Weeks 21–32, ~3 months)

**Goal:** Full project intelligence — the feature that actually differentiates ECIP from RAG-only tools.

### Weeks 21–23 — Extend the Graph to Business/Architecture Layer
- Week 21: Add Kafka topic nodes + PUBLISHES_TO/CONSUMES_FROM edges (parse `@KafkaListener`/producer code).
- Week 22: Add React component ↔ API endpoint edges (CALLS_API) using Week 20's parser output, linking frontend to backend.
- Week 23: Add microservice-level nodes (if multi-repo) — one node per service, with cross-service edges based on shared API contracts.

### Weeks 24–26 — Impact Analysis Engine
- Week 24: Write the traversal algorithm: given a starting node (e.g., a column or field), do a reverse-BFS/DFS up the graph to find everything that reads/writes/depends on it. Cap traversal depth to avoid graph explosion; surface confidence/depth in the answer.
- Week 25: Format impact analysis output clearly (the structured tree shown in Master Doc 4.4's example) — this is your headline demo feature, so the output presentation matters as much as the logic.
- Week 26: Test against real "rename this field" / "delete this method" scenarios on the reference repo. Manually verify every result — false negatives here (missing a real dependency) are worse than the feature not existing.

### Weeks 27–29 — Project Memory
- Week 27: Design the Project Memory schema (Master Doc 4.5): coding standards, architecture decisions, naming conventions, exception-handling rules — stored as structured facts (JSON or small SQLite table), not free text.
- Week 28: Build auto-extraction: scan the codebase for repeated patterns (e.g., "90% of services use constructor injection") and auto-populate memory with a confidence score; allow manual override/addition.
- Week 29: Inject Project Memory into every prompt as a "[SYSTEM CONTEXT]" block (per Master Doc 4.2's prompt structure) and verify the LLM's generated code actually follows it consistently across 20+ generation requests.

### Weeks 30–32 — Phase 3 Hardening
- Week 30: Build a regression eval suite specifically for impact analysis (10+ known-correct dependency chains from the real repo) — re-run after every graph change.
- Week 31: Performance pass: graph traversal speed, embedding/index rebuild time for incremental changes.
- Week 32: Internal demo focused entirely on impact analysis + memory-driven code generation. This is the milestone worth pitching to leadership as a major checkpoint.

**✅ Phase 3 Definition of Done:** "What breaks if I rename this field?" returns a verifiably correct, complete impact map. Generated code reliably follows company standards without being told each time.

---

## PHASE 4 — Enterprise Features (Weeks 33–44, ~3 months)

**Goal:** Production-shaped platform, not a personal tool.

- **Weeks 33–35 — IntelliJ Plugin:** Scaffold via IntelliJ Platform SDK (Kotlin), port the chat UI and citation-jump logic from the VS Code extension.
- **Weeks 36–37 — Server Deployment Mode:** Containerize the backend (Docker), add a config switch for "laptop mode" (local FAISS/SQLite) vs "server mode" (Qdrant + Neo4j server + shared GPU inference via vLLM).
- **Weeks 38–39 — Shared Team Knowledge Base:** Multi-user access to one indexed repo + graph (instead of per-laptop local index); add basic auth.
- **Weeks 40–41 — Coding Standards Enforcement in Review:** A lightweight CLI/CI hook that runs Project Memory checks against a diff and flags violations before merge.
- **Weeks 42–43 — JUnit Test Generation with Full Context:** Use retrieval + graph context (existing test patterns, mocked dependencies) to generate tests that match the codebase's actual testing style, not generic JUnit boilerplate.
- **Week 44 — Web Portal (minimal):** A simple React dashboard for non-IDE users (search, ask questions, view impact analysis) — reuse the backend API built since Phase 1.

**✅ Phase 4 Definition of Done:** A second developer (not you) can install the plugin, point it at a shared server deployment, and use it daily without your direct help.

---

## PHASE 5 — Agentic Features (Weeks 45+, ongoing)

This phase is genuinely open-ended and should only start after Phase 4 has real users and feedback. Don't pre-build agentic features speculatively — they're the most likely part of the original roadmap to need a full redesign once you see real usage patterns.

- Multi-step task execution (implement a feature across backend/frontend/tests)
- Automated impact analysis triggered on every Git commit (CI integration)
- Proactive architecture-violation warnings during development
- Continuous fine-tuning loop using real accepted/rejected suggestions as training signal

---

## Running Checklist — Things to Do Throughout (Not Just Once)

- [ ] Re-run your eval suite after every significant change (build this in Week 8, never skip it after)
- [ ] Keep a running log of retrieval/graph failures on real questions — this is your best source of what to fix next
- [ ] Re-validate against the *real* reference repo at the end of every phase, not just synthetic test cases
- [ ] Keep cost tracking (GPU rental hours, any cloud spend) from Day 1 — useful both for your own budgeting and for the business case when you pitch
- [ ] At each phase boundary, consider a short internal demo/checkpoint — this builds the narrative for leadership incrementally instead of one big reveal at the end

---

## Time & Effort Summary

| Phase | Duration | Cumulative |
|---|---|---|
| Phase 1 — Foundation & Basic RAG | 8 weeks | 8 weeks |
| Phase 2 — Parsers & Dependency Graph | 12 weeks | 20 weeks |
| Phase 3 — Knowledge Graph & Impact Analysis | 12 weeks | 32 weeks |
| Phase 4 — Enterprise Features | 12 weeks | 44 weeks |
| Phase 5 — Agentic Features | Ongoing | — |

**~44 weeks (≈10–11 months) of focused, full-time-equivalent work** to reach Phase 4 completion. If working part-time alongside your regular R&D role, expect **14–18 months** realistically — this is consistent with (slightly more detailed than) the Master Doc's original 12–15 month estimate, now broken into something you can actually schedule against.

This is the honest "how." It's a real project, not a weekend one — but it's also entirely achievable in stages, with a genuinely demo-worthy, pitchable checkpoint at the end of every phase.
