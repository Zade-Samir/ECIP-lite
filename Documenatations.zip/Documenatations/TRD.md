# Technical Requirement Document (TRD) — Enterprise Code Intelligence Platform (ECIP)

## 1. System Architecture Overview
ECIP uses a modular client-server architecture designed to run either entirely on a single developer workstation (Laptop Mode) or shared within a firewalled enterprise subnet (Server Mode). The backend is a Python-based service framework utilizing FastAPI, which interfaces with a localized vector database, a localized graph database, and a local inference server.

---

## 2. Technology Stack & Component Selection

| Sub-system | Technology | Version | Selection Rationale |
| :--- | :--- | :--- | :--- |
| **Inference Server** | Ollama / vLLM | v0.1.48+ / v0.4.0+ | **Ollama:** Best-in-class local model loading and quantization orchestration on macOS/Windows. <br>**vLLM:** Optimal throughput via paged attention for server deployments. |
| **Backend Core Framework** | FastAPI (Python) | 0.110.0+ | High-performance asynchronous endpoint routing, native JSON validation via Pydantic, and low overhead. |
| **Vector Database** | FAISS / Qdrant | v1.7.4+ / v1.8.0+ | **FAISS:** File-based local vector store with zero service dependencies. <br>**Qdrant:** Ideal for server deployments requiring metadata filtering and cluster replication. |
| **Graph Database** | Neo4j Community | v5.18.0+ | Native graph indexing. Provides Cypher query language support which is required for multi-hop structural impact traversals. |
| **Java Code Parser** | JavaParser / javalang | v3.25.9 / v0.13.0 | JavaParser (JVM-native) provides AST representation. Python bridge (`javalang`) handles fast token scanning. |
| **SQL Parser** | sqlglot | v23.0.0+ | Pure-Python parser supporting dialect translations, table extraction, and mapping queries to JPA models. |
| **Git Integration** | GitPython | v3.1.43 | Standard wrapper around git command binaries, providing efficient history walker mechanisms. |
| **Embedding Model** | BAAI/bge-code-v1 | base (local) | Specialized code-retrieval embeddings that represent code structures better than standard text representations. |

---

## 3. Hardware Requirements & Quantization Metrics

### 3.1 Workstation Deployment (Laptop Mode)
- **CPU:** AMD Ryzen 5 Pro / Intel Core i7 (6+ Cores) or Apple M1/M2/M3 Silicon.
- **System Memory:** Minimum 16 GB DDR4/DDR5 RAM.
- **Storage:** NVMe SSD with at least 20 GB free space (5 GB for index cache, 10 GB for model weights, 5 GB for dependencies).
- **GPU:** Radeon 760M iGPU, Intel Iris Xe, or Apple Unified Memory. Dedicated GPU is optional; the software utilizes unified memory dynamically.

### 3.2 Server-Class Deployment (Server Mode)
- **CPU:** AMD EPYC or Intel Xeon (16+ Cores).
- **System Memory:** 64 GB+ RAM.
- **Storage:** Enterprise SSD in RAID 10 configuration.
- **GPU:** 1x NVIDIA A10G / L4 (24GB VRAM) or A100 (40GB/80GB VRAM) to support multi-user inference concurrency.

### 3.3 Model Sizing & Quantization Constraints
To run within the 16 GB workstation memory footprint, models must be quantized to **4-bit (Q4_K_M)**:

- **Qwen2.5-Coder-7B-Instruct (Q4_K_M):**
  - File Size: ~4.7 GB.
  - Active VRAM/RAM footprint: ~5.8 GB.
  - Average execution speed on 16GB laptop: ~25-35 tokens/sec.
- **DeepSeek-Coder-V2-Lite-16B (Q4_K_M):**
  - File Size: ~9.5 GB.
  - Active VRAM/RAM footprint: ~11.2 GB.
  - Average execution speed on 16GB laptop: ~10-15 tokens/sec (borderline performance limit).

---

## 4. Security & Network Posture

### 4.1 Air-Gapped Network Configuration
- **Isolation Policy:** The application must contain no outward API calls to public DNS records. All update checks or model sync operations must occur via manual tarball imports approved by internal IT.
- **Local Bindings:** By default, in Laptop Mode, the FastAPI server, FAISS storage, and Ollama server must bind exclusively to `127.0.0.1` interfaces. External access to port `8000` (FastAPI) or `11434` (Ollama) must be blocked by system firewall policies.

### 4.2 Telemetry & Audit Logging
- **Local Storage:** All runtime metrics, prompt logs, and telemetry must be stored in a local SQLite file (`~/ecip-data/audit.db`) or structured JSON files.
- **Audit Trails:** Logs must record the developer ID, file hash analyzed, query metadata, response latency, and target branch. No code snippets should leak into logging servers unless explicit opt-in policy is flagged by system administrators.

---

## 5. System Data Schema Requirements

### 5.1 FAISS Metadata Schema
Each chunk stored in the vector database index (`index.faiss`) must link to a metadata entry in `metadata.json`:
```json
{
  "chunk_id": "c_user_service_102",
  "file_path": "src/main/java/com/company/service/UserService.java",
  "content_hash": "a1b2c3d4e5f6g7h8",
  "start_line": 45,
  "end_line": 88,
  "code_signature": "public User createUser(UserDTO dto)",
  "language": "java"
}
```

### 5.2 Neo4j Graph Database Schema
The schema must support semantic relationships extracted from code parsing:
- **Node Definitions:**
  - `Class` (properties: `name`, `path`, `package`)
  - `Method` (properties: `name`, `signature`, `returnType`)
  - `Endpoint` (properties: `path`, `httpMethod`)
  - `DatabaseTable` (properties: `name`, `engine`)
  - `DatabaseColumn` (properties: `name`, `type`, `primaryKey`)
- **Relationship Definitions:**
  - `(:Class)-[:HAS_METHOD]->(:Method)`
  - `(:Method)-[:CALLS]->(:Method)`
  - `(:Method)-[:QUERIES]->(:DatabaseTable)`
  - `(:Endpoint)-[:ROUTES_TO]->(:Method)`
  - `(:Class)-[:DEPENDS_ON]->(:Class)`

---

## 6. API Interface Definitions
The core backend service must expose the following asynchronous REST APIs:

### 6.1 Chat Completion `/api/v1/chat`
- **HTTP Method:** `POST`
- **Request Body:**
  ```json
  {
    "query": "Explain candidate approval flow",
    "file_context": {
      "path": "src/main/java/com/company/controller/CandidateController.java",
      "line_range": [10, 50]
    },
    "history": [
      {"role": "user", "content": "How do we validate candidate inputs?"}
    ]
  }
  ```
- **Response Format:** Chunked Server-Sent Events (SSE) streaming data tokens, with final payload metadata containing citations:
  ```json
  {
    "citations": [
      {
        "file_path": "src/main/java/com/company/service/CandidateService.java",
        "lines": "34-60"
      }
    ]
  }
  ```

### 6.2 Impact Analysis `/api/v1/impact`
- **HTTP Method:** `POST`
- **Request Body:**
  ```json
  {
    "target_node": "CandidateEntity.status",
    "target_type": "DatabaseColumn"
  }
  ```
- **Response Format:**
  ```json
  {
    "impacted_components": [
      {
        "component": "src/main/java/com/company/dto/CandidateDTO.java",
        "type": "JavaClass",
        "relationship_path": "DatabaseColumn -> JPAEntityMapping -> DTO"
      }
    ]
  }
  ```
