# User Stories & Acceptance Criteria — Enterprise Code Intelligence Platform (ECIP)

This document contains Epic definitions, User Stories, and their corresponding validation criteria using the Gherkin syntax (Given-When-Then) where applicable.

---

## EPIC 1: Local Inference & Core Framework Setup

### US-1: Local Model Connection Setup
- **Story:** As an Enterprise Developer, I want the ECIP daemon to connect directly to my local Ollama instance so that my code inputs never escape the boundaries of my local computer.
- **Acceptance Criteria:**
  - **Scenario 1: Connect to localhost Ollama socket**
    - **Given** the Ollama service is running on `127.0.0.1:11434`
    - **When** the ECIP daemon initializes
    - **Then** it must execute a connection check API request (`/api/tags`) to verify target model availability.
  - **Scenario 2: Model availability verification**
    - **Given** the daemon has verified connection to Ollama
    - **When** the model name `qwen2.5-coder:7b-instruct` is declared in configuration
    - **Then** the daemon must confirm the model is present, returning HTTP 200 on server health checks, or return HTTP 503 explaining that the model must be downloaded.
  - **Scenario 3: Fail on external connection attempt**
    - **Given** an active runtime workspace
    - **When** a model completion is requested
    - **Then** the network manager must enforce that no outbound HTTP requests to external domains (e.g. `api.openai.com`) are executed.

### US-2: Local Transaction Audit Logging
- **Story:** As a Security Officer, I want all developer queries and daemon processes logged to a local file so that I can audit historical usages without leaking code to the cloud.
- **Acceptance Criteria:**
  - **Given** the developer triggers a code completion or chat query
  - **When** the daemon receives the payload
  - **Then** it must write transaction metadata (`developer_id`, `timestamp`, `query_length`, `response_latency`) to the local SQLite audit table.
  - **And** the query text itself must not be forwarded to external servers.

---

## EPIC 2: Intelligent Ingestion & Retrieval

### US-3: AST-Aware Java Code Parsing
- **Story:** As a Software Architect, I want Java source files parsed into structural representations (classes, methods, dependencies) so that the engine understands code logic instead of just words.
- **Acceptance Criteria:**
  - **Given** a directory scan has been triggered on the repository
  - **When** a `.java` file containing spring controller annotations is processed
  - **Then** the parser must isolate:
    - Target Class Name and Package coordinates.
    - Annotations like `@RestController` or `@Service`.
    - Declared class methods with signatures and list of method calls.
    - Declared variables and constructor-injected dependencies.
  - **And** write this structured index data to the DB layers.

### US-4: Hybrid Search Context Assembly
- **Story:** As a Developer, I want code search results to combine semantic meanings and exact keyword matches so that I get complete reference context for my queries.
- **Acceptance Criteria:**
  - **Given** a developer query like `"find CandidateStatus enum usage"`
  - **When** the Search Service executes retrieval
  - **Then** it must combine vector matching results (semantic meanings) and BM25 database search results (exact text strings).
  - **And** deduplicate findings based on chunk IDs.
  - **And** re-rank results using a local cross-encoder, outputting the top-5 most relevant text chunks into the final prompt.

---

## EPIC 3: Dependency Mapping & Impact Analysis

### US-5: Dependency Graph Mapping in Neo4j
- **Story:** As a Software Architect, I want dependency relationships mapped to a graph database so that I can visualize compile-time and database relations.
- **Acceptance Criteria:**
  - **Given** Java parser has finished parsing file ASTs
  - **When** classes contain constructor injection dependencies or mapping annotations
  - **Then** the graph builder must execute Cypher queries to create nodes (`Class`, `Method`) and connect them with edges (`CALLS`, `DEPENDS_ON`).

### US-6: Upstream/Downstream Impact Analysis
- **Story:** As a Developer, I want to query what components will break if I modify a code component so that I can refactor without introducing regressions.
- **Acceptance Criteria:**
  - **Given** the developer requests an impact report for a method `CandidateService.delete()`
  - **When** the daemon executes a path query
  - **Then** it must run a Neo4j traversal up to 5 levels deep to locate callers of that method.
  - **And** return a tree listing all class paths, calling methods, REST routes, and associated JUnit tests.

---

## EPIC 4: Developer Integration & User Experience

### US-7: VS Code Sidebar Chat Panel
- **Story:** As a Developer, I want a chat panel in my VS Code sidebar so that I can ask questions about my workspace code without switching windows.
- **Acceptance Criteria:**
  - **Given** the VS Code extension is active
  - **When** the developer opens the sidebar view
  - **Then** the Webview must connect to the local FastAPI socket at port 8000.
  - **And** display a chat entry bar, indexing status values, and a list of citation links.

### US-8: Inline Focus Jump Citations
- **Story:** As a Developer, I want citations in ECIP responses to open the code file at the correct line on click so that I can quickly verify recommendations.
- **Acceptance Criteria:**
  - **Given** ECIP outputs an answer containing citation links (e.g. `UserService.java:L45-88`)
  - **When** the developer clicks on the citation hyperlink
  - **Then** VS Code must focus the active editor window.
  - **And** open `UserService.java` highlighting lines 45 through 88.
