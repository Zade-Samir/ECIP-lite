# Component Flowchart — Enterprise Code Intelligence Platform (ECIP)

This document contains step-by-step logic workflows for the three main engines of ECIP: **File Ingestion & Parsing**, **Search & Inference Retrieval**, and **Impact Analysis**.

---

## 1. File Indexing and AST Ingestion Pipeline
This pipeline runs in the background to recursively scan the workspace, track modification deltas via hashes, extract structural AST boundaries, and update storage targets.




```mermaid
VS Code Extension
        │
        ▼
FastAPI Backend
        │
        ▼
Query Coordinator
        │
 ┌──────┼─────────┐
 │      │         │
 ▼      ▼         ▼
Parser FAISS Project Memory
 │      │
 ▼      ▼
SQLite
        │
        ▼
Prompt Builder
        │
        ▼
Ollama
        │
        ▼
Qwen Model
```
```mermaid


sequenceDiagram
    autonumber
    participant IDE as Developer Workspace
    participant FW as File Walker (Daemon)
    participant DB_SQL as SQLite Cache Catalog
    participant PR as Parsing Router
    participant DB_VEC as FAISS Vector Store
    participant DB_GRPH as Neo4j Graph DB

    Note over IDE, FW: Triggered by filesystem save or manual scan command
    FW->>IDE: Scan directories (filtering by .gitignore)
    IDE-->>FW: Return files list
    FW->>DB_SQL: Fetch cached file paths and hashes
    DB_SQL-->>FW: Return dictionary of {path: hash}
    
    loop For each file
        FW->>FW: Calculate current MD5 hash
        alt Hash matches cached hash
            Note over FW: Skip file processing (No delta detected)
        else Hash is new or changed
            FW->>PR: Send file path and raw content
            activate PR
            
            alt File is *.java
                PR->>PR: Run Java AST Parser (Extract classes, methods, dependencies, endpoints)
            else File is *.sql
                PR->>PR: Run SQL DDL Parser (Extract tables, columns, relations)
            else File is *.yml / *.xml
                PR->>PR: Run Config Parser (Extract dependencies and profiles)
            end
            
            PR->>DB_GRPH: Write structural nodes and edges (Cypher transactions)
            PR->>PR: Extract logical text chunks (Class/Method bounds)
            PR->>PR: Generate vector embeddings via local SentenceTransformer
            PR->>DB_VEC: Add vectors with chunk IDs
            PR->>DB_SQL: Save chunk mappings, line references, and new file hash
            deactivate PR
        end
    end
```

---

## 2. Search & Inference Retrieval Flowchart
This diagram outlines the process of translating a developer’s query into a prompt that is grounded in the company's codebase and structural dependencies.

```mermaid
graph TD
    UserQuery([Developer types query in Extension]) --> SearchService[search_service.py Core Router]
    
    subgraph Parallel_Search["Parallel Retrieval"]
        SearchService -->|Vector Embed Query| EmbedModel[Local Embedding Model]
        EmbedModel -->|Fetch top-k| FAISS_DB[(FAISS Vector Store)]
        SearchService -->|Keyword matching| BM25[BM25 keyword lookup]
        SearchService -->|Class/Entity nodes matched| GraphDB[(Neo4j Graph DB)]
    end
    
    FAISS_DB --> RRF[Reciprocal Rank Fusion RRF Merger]
    BM25 --> RRF
    
    RRF --> TopChs[Get Top-20 merged chunks]
    TopChs --> CrossEncoder[Cross-Encoder Reranker]
    CrossEncoder --> Top5[Get Top-5 highly relevant chunks]
    
    GraphDB -->|Find 1-hop dependencies| GraphContext[Fetch call graphs & schema mappings]
    
    Top5 --> PromptBuilder[Prompt Builder]
    GraphContext --> PromptBuilder
    
    subgraph Prompt_Assembly["Prompt Assembly Engine"]
        PromptBuilder -->|Prepend context rules| Memory[Project Memory JSON Config]
        Memory --> Assembly[Structure LLM Prompt Template]
    end
    
    Assembly --> OllamaAPI[Ollama Local Inference API]
    OllamaAPI -->|Stream response tokens| ExtensionUI([IDE Chat Webview Panel])
```

---

## 3. Graph Traversal Impact Analysis Algorithm
The workflow executed when a developer queries which items will break if they rename a column, delete a service method, or alter class variables.

```mermaid
graph TD
    StartInput([Input: target_node, target_type]) --> FindNode{Find matching node in Neo4j?}
    
    FindNode -->|No| ErrReturn[Return empty list / Node not found]
    FindNode -->|Yes| SetQueue[Initialize Queue & Visited Set]
    
    SetQueue --> EnqueueStart[Enqueue starting node]
    
    %% Traverse Loop
    QueueCheck{Is Queue empty?} -->|Yes| FormatRes[Format paths and trace history]
    QueueCheck -->|No| Dequeue[Dequeue current_node]
    
    Dequeue --> QueryNeighbors[Query Neo4j: MATCH Path = current_node -[:CALLS | DEPENDS_ON | MAPPED_TO]-> Neighbors]
    
    QueryNeighbors --> LoopNeighbors{Process each neighbor}
    
    LoopNeighbors -->|Done| QueueCheck
    LoopNeighbors -->|Next neighbor| VisitedCheck{Has neighbor been visited?}
    
    VisitedCheck -->|Yes| LoopNeighbors
    VisitedCheck -->|No| AddPath[Record path trace details]
    
    AddPath --> EnqueueNeighbor[Enqueue neighbor & Add to Visited Set]
    EnqueueNeighbor --> LoopNeighbors
    
    FormatRes --> VerifyFiles[Cross-reference target file offsets in SQLite Catalog]
    VerifyFiles --> OutputResponse([API Response: List of impacted classes, files, lines, and trace paths])
```
